#关于猫脸检测程序的说明#

###运行及开发环境：VisualStdio 2015 + OpenCV 3.3 + Python 2.7/3.5.2（受h5py包和其他依赖项支持）

###主程序为CanScanX.py，X为版本号，但囿于时间、精力及其他未知问题，此程序依旧不完善，存在BUG

###感谢来自GitHub的@aeddi 在其开源项目中提供了aws-lambda-python-opencv && Thanks for @aeddi: https://github.com/aeddi/aws-lambda-python-opencv

###识别率计算方式：每次计算经由百度图片提供的API接口调用300张图片跑完程序后由三位成员进行人工检查得出平均正确率

###作者：王彦真 穆永誉 戚子强 From 东北大学 ###
###时间：2017年8月25日 11:27 UTC Asian/Shanghai ###
<!--所有相关资料、程序仅供本次数学建模练习和学习使用-->
<!--END-->