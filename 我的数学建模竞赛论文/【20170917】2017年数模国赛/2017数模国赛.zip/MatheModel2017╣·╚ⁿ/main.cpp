#include <fstream>
#include <string>
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    ifstream in("1.txt");
    ofstream out("2.txt");
    string filename;
    string line;
    double a,b;

    if(in) // �и��ļ�
    {
        while (getline (in, line)) // line�в�����ÿ�еĻ��з�
        {
            in>>a>>b;
            out << setprecision(15) << b << endl; // ���뵽2.txt��
        }
    }
    else // û�и��ļ�
    {
        cout <<"no such file" << endl;
    }

    return 0;
}